﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace KHerring.Models
{
    public class NavigationLink
    {
        public string Title { get; set; }
        public string View { get; set; }
        public string ControllerName { get; set; }
    }
}